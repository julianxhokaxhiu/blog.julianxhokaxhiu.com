#!/sbin/sh

BIN=/sdcard/supersu/arm
COM=/sdcard/supersu/common

set_perm() {
	chown $1.$2 $4
	chown $1:$2 $4
	chmod $3 $4
}

echo "*****************************************************"
echo "SuperSU installer Script - Modded by Julian Xhokaxhiu"
echo "*****************************************************"

echo ">> Initializing..."
ln -s /system/bin/busybox /system/bin/cp

echo ">> Mounting / and /system as read/write"
mount -o rw,remount /system

echo ">> Removing old files"
rm -f /system/bin/su 2> /dev/null
rm -f /system/xbin/su 2> /dev/null
rm -f /system/xbin/daemonsu 2> /dev/null
rm -f /system/bin/.ext/.su 2> /dev/null
rm -f /system/etc/install-recovery.sh 2> /dev/null
rm -f /system/etc/init.d/99SuperSUDaemon 2> /dev/null
rm -f /system/etc/.installed_su_daemon 2> /dev/null
rm -f /system/app/Superuser.apk 2> /dev/null
rm -f /system/app/Superuser.odex 2> /dev/null
rm -f /system/app/SuperUser.apk 2> /dev/null
rm -f /system/app/SuperUser.odex 2> /dev/null
rm -f /system/app/superuser.apk 2> /dev/null
rm -f /system/app/superuser.odex 2> /dev/null
rm -f /system/app/Supersu.apk 2> /dev/null
rm -f /system/app/Supersu.odex 2> /dev/null
rm -f /system/app/SuperSU.apk 2> /dev/null
rm -f /system/app/SuperSU.odex 2> /dev/null
rm -f /system/app/supersu.apk 2> /dev/null
rm -f /system/app/supersu.odex 2> /dev/null
rm -f /data/dalvik-cache/*com.noshufou.android.su* 2> /dev/null
rm -f /data/dalvik-cache/*com.koushikdutta.superuser* 2> /dev/null
rm -f /data/dalvik-cache/*com.mgyun.shua.su* 2> /dev/null
rm -f /data/dalvik-cache/*Superuser.apk* 2> /dev/null
rm -f /data/dalvik-cache/*SuperUser.apk* 2> /dev/null
rm -f /data/dalvik-cache/*superuser.apk* 2> /dev/null
rm -f /data/dalvik-cache/*eu.chainfire.supersu* 2> /dev/null
rm -f /data/dalvik-cache/*Supersu.apk* 2> /dev/null
rm -f /data/dalvik-cache/*SuperSU.apk* 2> /dev/null
rm -f /data/dalvik-cache/*supersu.apk* 2> /dev/null
rm -f /data/dalvik-cache/*.oat 2> /dev/null
rm -f /data/app/com.noshufou.android.su-* 2> /dev/null
rm -f /data/app/com.koushikdutta.superuser-* 2> /dev/null
rm -f /data/app/com.mgyun.shua.su-* 2> /dev/null
rm -f /data/app/eu.chainfire.supersu-* 2> /dev/null

echo ">> Placing files"
mkdir /system/bin/.ext
cp $BIN/su /system/xbin/daemonsu
cp $BIN/su /system/xbin/su
cp $BIN/su /system/bin/.ext/.su
cp $COM/Superuser.apk /system/app/Superuser.apk
cp $COM/install-recovery.sh /system/etc/install-recovery.sh
mkdir /system/etc/init.d
cp $COM/99SuperSUDaemon /system/etc/init.d/99SuperSUDaemon
echo 1 > /system/etc/.installed_su_daemon

echo ">> Setting permissions"
set_perm 0 0 0777 /system/bin/.ext
set_perm 0 0 06755 /system/bin/.ext/.su
set_perm 0 0 06755 /system/xbin/su
set_perm 0 0 06755 /system/xbin/daemonsu
set_perm 0 0 0755 /system/etc/install-recovery.sh
set_perm 0 0 0755 /system/etc/init.d/99SuperSUDaemon
set_perm 0 0 0644 /system/etc/.installed_su_daemon
set_perm 0 0 0644 /system/app/Superuser.apk

echo ">> Done!"