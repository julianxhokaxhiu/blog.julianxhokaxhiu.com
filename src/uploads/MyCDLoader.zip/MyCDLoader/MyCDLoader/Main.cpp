#include "resource.h"
#include <direct.h> // for getcwd
#include <stdlib.h>// for MAX_PATH
#include <windows.h>
#include <windowsx.h>

#define IDT_TIMER1 1000

LRESULT CALLBACK WndProc (HWND, UINT, WPARAM, LPARAM);
HBITMAP hBitmap;
PAINTSTRUCT ps;
HDC hdc;

// Get information about Chrome
PROCESS_INFORMATION pif;  //Gives info on the thread and..
						  //..process for the new process
STARTUPINFO si;           //Defines how to start the program

/* Function CenterWindow(), Centers Window */
VOID CenterWindow(HWND hwnd, HWND hwndParent, int Width, int Height)
{

	/* Variables */
	RECT rc;

	/* If Parent Window Is Set As Null, Get The Desktop Window */
	if(hwndParent == NULL)
		hwndParent = GetDesktopWindow();

	/* Get Parent Client Area Measurements */
	GetClientRect(hwndParent, &rc);

	/* Center The Window */
	MoveWindow(
		hwnd,
		(rc.right - rc.left - Width) / 2,
		(rc.bottom - rc.top - Height) / 2,
		Width,
		Height,
		TRUE
	);

	return;

}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
  static char szAppName[] = "My CD Loader" ;
  HWND        hwnd ;
  MSG         msg ;
  WNDCLASSEX  wndclass ;

  wndclass.cbSize        = sizeof (wndclass) ;
  wndclass.style         = CS_HREDRAW | CS_VREDRAW ;
  wndclass.lpfnWndProc   = WndProc ;
  wndclass.cbClsExtra    = 0 ;
  wndclass.cbWndExtra    = 0 ;
  wndclass.hInstance     = hInstance ;
  wndclass.hIcon         = LoadIcon (NULL, IDI_APPLICATION) ;
  wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW) ;
  wndclass.hbrBackground = (HBRUSH) GetStockObject (WHITE_BRUSH) ;
  wndclass.lpszMenuName  = NULL ;
  wndclass.lpszClassName = szAppName ;
  wndclass.hIconSm       = LoadIcon (NULL, IDI_APPLICATION) ;

  RegisterClassEx (&wndclass) ;

  hwnd = CreateWindow(szAppName,   // window class name
    NULL,     // window caption
    WS_POPUP,     // window style
    CW_USEDEFAULT,           // initial x position
    CW_USEDEFAULT,           // initial y position
    367,           // initial x size
    192,           // initial y size
    NULL,                    // parent window handle
    NULL,                    // window menu handle
    hInstance,               // program instance handle
    NULL) ;		       // creation parameters

  ShowWindow (hwnd, iCmdShow) ;
  UpdateWindow (hwnd) ;
  CenterWindow(hwnd, NULL, 367, 192);
  SetTimer(hwnd,             // handle to main window 
    IDT_TIMER1,            // timer identifier 
    1000,                 // 10-second interval 
    (TIMERPROC) NULL);     // no timer callback 

  while (GetMessage (&msg, NULL, 0, 0))
  {
    TranslateMessage (&msg) ;
    DispatchMessage (&msg) ;
  }

  return msg.wParam ;
}

LRESULT CALLBACK WndProc (HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
  switch (iMsg)
  {
	case WM_CREATE :
	  {
		  // The bitmap should be stored as a resource in the exe file.
		  // We pass the hInstance of the application, and the ID of the
		  // bitmap to the LoadBitmap API function and it returns us an
		  // HBITMAP to a DDB created from the resource data.
		  HINSTANCE hInstance = GetWindowInstance(hwnd);
		  hBitmap = LoadBitmap(hInstance,MAKEINTRESOURCE(IDB_BITMAP1));

		  // Start Google Chrome
		  // _MAX_PATH is the maximum length allowed for a path
		  char CurrentPath[_MAX_PATH];
		  char SysLaunch[_MAX_PATH];
		  // use the function to get the path
		  _getcwd(CurrentPath, _MAX_PATH);
		  strcpy_s(SysLaunch, CurrentPath);
		  strcat_s(SysLaunch, "\\GoogleChromePortable\\GoogleChromePortable.exe --start-maximized --app=\"");
		  strcat_s(SysLaunch, CurrentPath);
		  strcat_s(SysLaunch, "\\start.html\"");

		  ZeroMemory(&si,sizeof(si)); //Zero the STARTUPINFO struct
		  si.cb = sizeof(si);         //Must set size of structure

		  BOOL bRet = CreateProcess(
				NULL, //Path to executable file
				SysLaunch,   //Command string - not needed here
				NULL,   //Process handle not inherited
				NULL,   //Thread handle not inherited
				FALSE,  //No inheritance of handles
				0,      //No special flags
				NULL,   //Same environment block as this prog
				NULL,   //Current directory - no separate path
				&si,    //Pointer to STARTUPINFO
				&pif);   //Pointer to PROCESS_INFORMATION

		  if(bRet == FALSE)
		  {
			MessageBox(HWND_DESKTOP,"Cannot run Google Chrome.","",MB_OK);
			PostQuitMessage (0);
		  }

		  return 0;
	  }
	case WM_PAINT :
		{
		  hdc = BeginPaint (hwnd, &ps);
		  // To paint with a DDB it first needs to be associated
		  // with a memory device context. We make a DC that
		  // is compatible with the screen by passing NULL to
		  // CreateCompatibleDC.
		  // Then we need to associate our saved bitmap with the
		  // device context.
  
		  HDC hdcMem = CreateCompatibleDC(NULL);
		  HBITMAP hbmT = SelectBitmap(hdcMem,hBitmap);
  
		  // Now, the BitBlt function is used to transfer the contents of the 
		  // drawing surface from one DC to another. Before we can paint the
		  // bitmap however we need to know how big it is. We call the GDI
		  // function GetObject to get the relevent details.
		  BITMAP bm;
		  GetObject(hBitmap,sizeof(bm),&bm);
  
		  BitBlt(hdc,0,0,bm.bmWidth,bm.bmHeight,hdcMem,0,0,SRCCOPY);
  
		  // Now, clean up. A memory DC always has a drawing
		  // surface in it. It is created with a 1X1 monochrome
		  // bitmap that we saved earlier, and need to put back
		  // before we destroy it.
		  SelectBitmap(hdcMem,hbmT);
		  DeleteDC(hdcMem);

		  // EndPaint balances off the BeginPaint call.
		  EndPaint (hwnd, &ps);
		  return 0;
		}
	case WM_TIMER :
		{
			switch (wParam) 
			{
				case IDT_TIMER1 :
					{
						if(!WaitForInputIdle(pif.hProcess, 0))
						{
							CloseHandle(pif.hProcess);   //Close handle to process
							CloseHandle(pif.hThread);    //Close handle to thread
							PostQuitMessage (0) ; // Quit from App
						}
						break;
					}
			}
			break;
		}
	case WM_DESTROY :
		  PostQuitMessage (0) ;
		  return 0 ;
  }

  return DefWindowProc (hwnd, iMsg, wParam, lParam) ;
}
